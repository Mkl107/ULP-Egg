package g6ejextra.j.a.r.v.i.s;

public class Botas {

    private float consumo=5;

    private double salud;

    public Botas(double salud) {
        this.salud = salud;
    }

    public double getSalud() {
        return salud;
    }
    
    public float usar(double tiempoMin,int intensidad) {
        if(salud>0){
            
            int probabilidadDaño=(int)(Math.random()*100)+1;
        
            switch(intensidad){
                case 1:{
                    if(probabilidadDaño<=30){
                       salud-=100*0.03;
                    }
                    return consumo*(float)tiempoMin;
                }
                case 2:{
                    if(probabilidadDaño<=30){
                       salud-=100*0.04;
                    }
                    return (consumo*2)*(float)tiempoMin;
                }
                case 3:{
                    if(probabilidadDaño<=30){
                       salud-=100*0.05;
                    }
                    return (consumo*3)*(float)tiempoMin;
                }
            }
        }else{
            salud=0;
            System.out.println("Dispositivo inutilizado");
        }
 
        return 0;
    }

    @Override
    public String toString() {
        return "{" + "salud=" + salud + '}';
    }

   
    
}
