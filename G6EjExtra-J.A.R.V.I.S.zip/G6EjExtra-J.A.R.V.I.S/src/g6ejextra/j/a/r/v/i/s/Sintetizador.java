package g6ejextra.j.a.r.v.i.s;

public class Sintetizador {

    private float consumo=3;

    private double salud;

    public Sintetizador(double salud) {
        this.salud = salud;
    }

    public double getSalud() {
        return salud;
    }
    
    public float usar(String texto) {
        if(salud>0){
            int probabilidadDaño=(int)(Math.random()*100)+1;
            if(probabilidadDaño<=30){
                salud-=100*0.2;
            }
            System.out.println(texto);
            return consumo;
        }else{
            salud=0;
            System.out.println("Dispositivo inutilizado");
        }
        return 0;
    }

    @Override
    public String toString() {
        return "Sintetizador{" + "salud=" + salud + '}';
    }
    
}
