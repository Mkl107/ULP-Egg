package g6ejextra.j.a.r.v.i.s;

public class Armadura {

    private String colorPrim;
    private String colorSecu;

    private Guantes guantesIz;
    private Guantes guantesDr;

    private Botas botasIz;
    private Botas botasDr;

    private int Rockwell;

    private double salud;

    private Reactor reactor;

    private Consola consola;
    
    private Sintetizador sintetizador;

    public Armadura(String colorPrim, String colorSecu,  int Rockwell) {
        this.colorPrim = colorPrim;
        this.colorSecu = colorSecu;
        this.Rockwell = Rockwell;
        this.salud = 100;
        this.reactor = new Reactor(3.4028235E38f, 100);
        this.sintetizador= new Sintetizador(100);
        this.consola =new Consola(100);
        this.guantesIz =new Guantes (100);
        this.guantesDr = this.guantesIz;
        this.botasIz =new Botas(100);
        this.botasDr = this.botasIz;
    }

    public Reactor getReactor() {
        return reactor;
    }


    public void caminar(double tiempo) {
        float consumo=(botasIz.usar(tiempo, 1)+botasDr.usar(tiempo, 1));  
        reactor.usar(consumo);
    }

    public void correr(double tiempo) {
        float consumo=(botasIz.usar(tiempo, 2)+botasDr.usar(tiempo, 2));
        reactor.usar(consumo);
    }

    public void propulsar(double tiempo) {
        float consumo=(botasIz.usar(tiempo, 3)+botasDr.usar(tiempo, 3));
        reactor.usar(consumo);
    }

    public void volar(double tiempo) {
        float consumoBotas=(botasIz.usar(tiempo, 3)+botasDr.usar(tiempo, 3));
        float consumoGuantes=(guantesDr.usar(tiempo, 2)+guantesIz.usar(tiempo, 2));
        reactor.usar(consumoBotas+consumoGuantes);
    }

    public String leer(int op) {
        switch(op){
            case 1:{
                //guantes
                return "Guante Dr "+guantesDr.toString()+"\n"
                        + "Guante Iz "+guantesIz.toString();
            }
            case 2:{
                //botas
                return "Bota Dr "+botasDr.toString()+"\n"
                        + "Bota Iz "+botasIz.toString();
            }
            case 3:{
                //consola
                return consola.toString();
            }
            case 4:{
                //sintetizador
                return sintetizador.toString();
            }
            case 5:{
                //reactor
                return reactor.toString();
            }
            case 6:{
                //todo
                return toString()+"\n"
                        + "Guante Dr "+guantesDr.toString()+"\n"
                        + "Guante Iz "+guantesIz.toString()+"\n"
                        + "Bota Dr "+botasDr.toString()+"\n"
                        + "Bota Iz "+botasIz.toString()+"\n"
                        + consola.toString()+"\n"
                        + sintetizador.toString()+"\n"
                        + reactor.toString();
            }
        }
        return "";
    }

    public void escribir(String texto, int op) {
        switch(op){
            case 1:{
                float consumo=consola.usar(texto);
                reactor.usar(consumo);
            }
            case 2:{
                float consumo=sintetizador.usar(texto);
                reactor.usar(consumo);
            }
        }
    }

    @Override
    public String toString() {
        salud=(botasDr.getSalud()+botasIz.getSalud()+guantesDr.getSalud()+guantesIz.getSalud()+reactor.getSalud()+sintetizador.getSalud()+consola.getSalud())/7;
        return "Armadura{" + "colorPrim=" + colorPrim + ", colorSecu=" + colorSecu + ", Dureza=" + Rockwell + ", salud=" + salud + " % }";
    }

}
