package g6ejextra.j.a.r.v.i.s;

public class Reactor {

    private float carga;

    private double salud;

    public Reactor(float carga, double salud) {
        this.carga = carga;
        this.salud = salud;
    }

    public double getSalud() {
        return salud;
    }

    public float getCarga() {
        return carga;
    }
    
    public void usar(float consumo ){
        if(salud>0){
            int probabilidadDaño=(int)(Math.random()*100)+1;
            if(probabilidadDaño<=30){
                salud-=100*0.05;
            }
            carga-=consumo;
        }else{
            salud=0;
            System.out.println("Dispositivo inutilizado");
        }
        
    }

    @Override
    public String toString() {
        return "Reactor{" + "carga=" + carga + ", salud=" + salud + '}';
    }
    
}
