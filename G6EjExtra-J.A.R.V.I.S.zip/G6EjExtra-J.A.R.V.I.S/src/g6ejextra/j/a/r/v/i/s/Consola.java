package g6ejextra.j.a.r.v.i.s;

public class Consola {

    private float consumo=1;
    private float salud;

    public Consola(float salud) {
        this.salud = salud;
    }

    public float getConsumo() {
        return consumo;
    }

    public float getSalud() {
        return salud;
    }
    
    public float usar(String texto) {
        if(salud>0){
            int probabilidadDaño=(int)(Math.random()*100)+1;
            
            if(probabilidadDaño<=30){
                salud-=100*0.05;
            }
            System.out.println(texto);
            return consumo;
        }else{
            salud=0;
            System.out.println("Dispositivo inutilizado");
        }
        
        return 0;
    }

    @Override
    public String toString() {
        return "Consola{" + "salud=" + salud + '}';
    }
    
}
