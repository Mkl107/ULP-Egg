package g6ejextra.j.a.r.v.i.s;

public class JARVIS {

    private Armadura armadura;

    public void estadoArmadura() {
        //por consola:
        armadura.escribir(armadura.leer(6), 1);
        //por sintetizador:
        armadura.escribir(armadura.leer(6), 2);
    }

    public void estadoBateria() {
        //por consola:
        armadura.escribir(armadura.leer(5), 1);
        //por sintetizador:
        armadura.escribir(armadura.leer(5), 2);
    }

    public void estadoDelReactor() {
        //obtenemos carga y luego convertir
        armadura.getReactor().getCarga();
    }

    public boolean reparar() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void revisarDispositivos() {
    }

    public void simulador() {
    }

    public void destruyendoEnemigos() {
    }

    public void accionesEvasivas() {
    }
}
